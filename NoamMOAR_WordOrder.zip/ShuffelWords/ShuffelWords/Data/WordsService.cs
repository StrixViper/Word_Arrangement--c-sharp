﻿using Microsoft.AspNetCore.Cors.Infrastructure;
using System.ComponentModel.DataAnnotations;


namespace ShuffelWords.Data
{
    public class WordsService
    {
        public bool IsFirstPlayer { get;  set; } = true;
        public int SelectedWordIndex { get; set; } = -1;
        public bool CanMoveUp { get => SelectedWordIndex > 0; }
        public int Count { get; set; } = 0;
        public bool CanMoveDown { get => SelectedWordIndex < Words.Length - 1; }
        public bool CanAddWord { get => SelectedWordIndex < Words.Length; }
        public bool CanRemoveWord { get => SelectedWordIndex > -1 && SelectedWordIndex < Words.Length; }
        public bool CanMoveToSecondPlayer { get => SelectedWordIndex == Words.Length || Count == Words.Length; }


        public string[] Words { get => IsFirstPlayer ? CorrectOrder : ScrambledWords; }

        public string[] CorrectOrder { get; set; } 
        public string[] ScrambledWords { get; set; }

        public void SelectWord(int index)
        {
            SelectedWordIndex = index;
        }

        public void Swap(int i, int j)
        {
            string temp = Words[i];
            Words[i] = Words[j];
            Words[j] = temp;
        }
        public void CountArry(int count)
        {
            CorrectOrder = new string[count];
            ScrambledWords = new string[count];
        }
        public void SetScrambledWords()
        {
            for (int i = 0; i< CorrectOrder.Length; i++)
                ScrambledWords[i] = CorrectOrder[i];
            Random random = new Random();
            for(int i = 0;i< ScrambledWords.Length; i++)
                Swap(i, random.Next(ScrambledWords.Length));
        }

        public void MoveToSecondPlayer()
        {
            IsFirstPlayer = false;
            SelectedWordIndex = -1;

            SetScrambledWords();
        }
        public bool IsCorrectOrder()
        {
            for (int i = 0; i < ScrambledWords.Length; i++)
            {
                if (ScrambledWords[i] != CorrectOrder[i])
                    return false;
            }
            return true;
        }


        public void AddWord(string word)
        {
            if (SelectedWordIndex == -1) { SelectedWordIndex = 0; }
            if(SelectedWordIndex == 0)
            {
                CorrectOrder[SelectedWordIndex] = word;
                SelectedWordIndex++;  
            }
            else if(SelectedWordIndex >= 1)
            {
                CorrectOrder[SelectedWordIndex] = word;
                SelectedWordIndex++;
            }
            Count++;
        }
        public void RemoveLastWord()
        {
            ScrambledWords[SelectedWordIndex] = "";
            CorrectOrder[SelectedWordIndex] = "";
            SelectedWordIndex--;
            Count--;
        }
        public void Restart(int count)
        {
            
            IsFirstPlayer = true;
            SelectedWordIndex = 0;
            CorrectOrder = new string[count];
            ScrambledWords = new string[count];
        }
    }
}